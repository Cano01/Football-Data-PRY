function requestInformacion(tipo, url, equipo){	
	const uri = url ; //modificar	
	let h = new Headers();
	h.append('Accept', 'application/json');
	h.append('X-Auth-Token','09efb2c2d25c4ac2a1bf2affb3e56b13')
	let req = new Request(uri, {
	    method: 'GET',
	    headers: h,
	    mode: 'cors'
	});
	fetch(req)
	    .then( (response)=>{
	        if(response.ok){
	            return response.json();
	        }else{
	            throw new Error('BAD HTTP stuff');
	        }
	    })
	    .then( (jsonData) =>{		    	
	    	if(tipo === 1){requestTablasFinales(jsonData);}
	    	if(tipo === 2){requestResultadosFinales(jsonData);}
	    	if(tipo === 3){requestHorariosFinales(jsonData);}
	    	if(tipo === 4){requestResultadosTemporada(jsonData);}
	    	if(tipo === 5){requestInformacionEquipo(jsonData, equipo);}
	    	if(tipo === 6){requestInformacionJugadores(jsonData);}
	    })
	    .catch( (err) =>{
	        console.log('ERROR:', err.message);
	    })
}


function accionAcordeon(){
	var acc = document.getElementsByClassName("accordion");
	var i;

	for (i = 0; i < acc.length; i++) {
	  acc[i].addEventListener("click", function() {
	    this.classList.toggle("active");
	    var panel = this.nextElementSibling;
	    if (panel.style.display === "block") {
	      panel.style.display = "none";
	    } else {
	      panel.style.display = "block";
	    }
	  });
	}
}

function requestTablasFinales(jsonData){	
	if(id == "WC"){
		if(document.getElementById('horario') != null){
				removeElement("horario");
		}
		if (document.getElementById('temporada') != null) {
				removeElement("temporada");
		}
		if(document.getElementById('acord') != null){
			removeElement("acord");
		}
	}   	
	var p = document.getElementById('content');
	if(document.getElementById('titulo1') == null){
		etapas1 = jsonData.competition;
		newElement = document.createElement('h1');
		newElement.innerHTML = "<h1 id='titulo1' style='text-align: center'>"+etapas1.name+"</h1>";
		//removeElement('titulo1');
		p.appendChild(newElement);
	}
    var newElement = document.createElement('div');
    newElement.setAttribute('id', 'contentInfo');
    p.appendChild(newElement);
	//*Se itera y agregan datos del json
	etapas = jsonData.standings

	//console.log(etapas);
	for( i = 0; i< etapas.length; i++){
		//*Se inserta la tabla
    	if(etapas[i].type === "TOTAL"){
        	p = document.getElementById('contentInfo');
		    newElement = document.createElement('table');
		    newElement.setAttribute('id', 'standingTable' + i);		    
		    if(etapas[i].group !== null && etapas[i].group !== ""){
		    	newElement.innerHTML = "<h3>"+ etapas[i].group+ "</h3><tr><td>Escudo</td><td>Equipo</td><td>PJ</td><td>PG</td><td>PP</td><td>PE</td><td>GF</td><td>GC</td><td>PTS</td></tr>";
		    }
		    else
		    {
		    	newElement.innerHTML = "<h3>"+ "TABLA"+ "</h3><tr><td>Escudo</td><td>Equipo</td><td>PJ</td><td>PG</td><td>PP</td><td>PE</td><td>GF</td><td>GC</td><td>PTS</td></tr>";
		    }
		    p.appendChild(newElement);
		    //*Se insertan elementos A LA NUEVA TABLA
		    for(j = 0; j<etapas[i].table.length; j++){

		    	escudo = etapas[i].table[j].team.crestUrl;
		    	if (escudo === "" || escudo ===null){
		    		escudo = "images/default.png"
		    	}
		    	nombre = etapas[i].table[j].team.name;
		    	pj = etapas[i].table[j].playedGames;
		    	pg = etapas[i].table[j].won;
		    	pp = etapas[i].table[j].lost;
		    	pe = etapas[i].table[j].draw;
		    	gf = etapas[i].table[j].goalsFor;
		    	gc = etapas[i].table[j].goalsAgainst;
		    	pts = etapas[i].table[j].points;

		    	//Se obtiene el padre donde se va a insertar elementos
		    	p = document.getElementById('standingTable' + i);
		    	//etiqueta del nuevo elemento
			    newElement = document.createElement('tr');
			    //Se setea el id del elemento
			    newElement.setAttribute('id', 'info' + j);			    
			    //Html que se va a agregar dentro del nuevo elemento
			    newElement.innerHTML =
			    "<td><button type = 'button' onclick = \"mostrarInformacionEquipo('"+nombre+"');\"'><img class = 'escudo' src="+escudo+"></td>"+"<td>"+nombre+"</td>"+
			    "<td>"+pj+"</td>"+"<td>"+pg+"</td>"+"<td>"+pp+"</td>"+"<td>"+pe+"</td>"+
			    "<td>"+gf+"</td>"+"<td>"+gc+"</td>"+"<td>"+pts+"</button></td>";
			    p.appendChild(newElement);
			}
		}
	}
}


function requestResultadosFinales(jsonData){		
	etapas = obtenerTablas(jsonData.matches);
	jornadas = obtenerJornadas(jsonData.matches);
	tablas = [];
	if(etapas.length > 1 && jornadas.length > 1){
		for (i = 0; i< jornadas.length; i++){
			etapas.push(jornadas[i]);
		}
		tablas = etapas;
	}
	if(etapas.length < 2){
		tablas = jornadas;
	}
	if(jornadas.length < 2){
		tablas = etapas;
	}
	var p = document.getElementById('content');
	var newElement = document.createElement('div');
	newElement.setAttribute('id', 'contentInfo');					
	p.appendChild(newElement);
	//*Se itera y agregan datos del json
	matches = jsonData.matches;
	for (t = 0; t < tablas.length; t++){
		if( tablas[t] !== null){
			p = document.getElementById('contentInfo');
		    newElement = document.createElement('div');	    
		    newElement.innerHTML = "<table id="+tablas[t]+">"+ "<tr><td>Jornada: "+ "</td><td>Equipo casa</td><td>Resultado</td><td>Equipo visita</td></tr></table>";
		    p.appendChild(newElement);
			for( i = 0; i< matches.length; i++){				
				if(matches[i].stage === tablas[t]){					
					nombreCasa = matches[i].homeTeam.name;
					nombreVisita =matches[i].awayTeam.name;
					score1 = matches[i].score.fullTime.homeTeam;
					score2 = matches[i].score.fullTime.awayTeam;
					p = document.getElementById(tablas[t]);					
					newElement = document.createElement('tr');					
					newElement.setAttribute('id', 'info' + i);					
					newElement.innerHTML =
					"<td>"+matches[i].stage+"</td><td>"+nombreCasa+"</td>"+"<td style='text-align:center'>"+score1+"-"+score2+"</td>"+"<td>"+nombreVisita+"</td>";
					p.appendChild(newElement);					
				}
				if(matches[i].matchday === tablas[t]){
					nombreCasa = matches[i].homeTeam.name;
					nombreVisita =matches[i].awayTeam.name;
					score1 = matches[i].score.fullTime.homeTeam;
					score2 = matches[i].score.fullTime.awayTeam;
					p = document.getElementById(tablas[t]);					
					newElement = document.createElement('tr');					
					newElement.setAttribute('id', 'info' + i);									
					newElement.innerHTML =
					"<td>"+matches[i].matchday+"</td><td>"+nombreCasa+"</td>"+"<td style='text-align:center'>"+score1+"-"+score2+"</td>"+"<td>"+nombreVisita+"</td>";
					p.appendChild(newElement);					
				}
			}
		}
	}
}

function requestResultadosTemporada(jsonData){	
	etapas = obtenerTablas(jsonData.matches);
	jornadas = obtenerJornadas(jsonData.matches);
	tablas = [];
	if(etapas.length > 1 && jornadas.length > 1){
		for (i = 0; i< jornadas.length; i++){
			etapas.push(jornadas[i]);
		}
		tablas = etapas;
	}
	if(etapas.length < 2){
		tablas = jornadas;
	}
	if(jornadas.length < 2){
		tablas = etapas;
	}
	var p = document.getElementById('content');
	var newElement = document.createElement('div');
	newElement.setAttribute('id', 'contentInfo');					
	p.appendChild(newElement);
	//*Se itera y agregan datos del json
	matches = jsonData.matches;
	for (t = 0; t < tablas.length; t++){
		if( tablas[t] !== null){
			p = document.getElementById('contentInfo');
		    newElement = document.createElement('div');	    
		    newElement.innerHTML = "<table id="+tablas[t]+">"+ "<tr><td>Jornada: "+ "</td><td>Equipo casa</td><td>Resultado</td><td>Equipo visita</td></tr></table>";
		    p.appendChild(newElement);
			for( i = 0; i< matches.length; i++){				
				if(matches[i].stage === tablas[t]){					
					nombreCasa = matches[i].homeTeam.name;
					nombreVisita =matches[i].awayTeam.name;
					score1 = matches[i].score.fullTime.homeTeam;
					score2 = matches[i].score.fullTime.awayTeam;
					p = document.getElementById(tablas[t]);					
					newElement = document.createElement('tr');					
					newElement.setAttribute('id', 'info' + i);					
					newElement.innerHTML =
					"<td>"+matches[i].stage+"</td><td>"+nombreCasa+"</td>"+"<td style='text-align:center'>"+score1+"-"+score2+"</td>"+"<td>"+nombreVisita+"</td>";
					p.appendChild(newElement);					
				}
				if(matches[i].matchday === tablas[t]){
					nombreCasa = matches[i].homeTeam.name;
					nombreVisita =matches[i].awayTeam.name;
					score1 = matches[i].score.fullTime.homeTeam;
					score2 = matches[i].score.fullTime.awayTeam;
					p = document.getElementById(tablas[t]);					
					newElement = document.createElement('tr');					
					newElement.setAttribute('id', 'info' + i);									
					newElement.innerHTML =
					"<td>"+matches[i].matchday+"</td><td>"+nombreCasa+"</td>"+"<td style='text-align:center'>"+score1+"-"+score2+"</td>"+"<td>"+nombreVisita+"</td>";
					p.appendChild(newElement);					
				}
			}
		}
	}
}

function requestHorariosFinales(jsonData){	   	
	jornadas = obtenerJornadas(jsonData.matches);		
	var p = document.getElementById('content');
    var newElement = document.createElement('div');
    newElement.setAttribute('id', 'contentInfo');    
    p.appendChild(newElement);
	//*Se itera y agregan datos del json
	encuentros = jsonData.matches
	//console.log(etapas);
	for(t = 0; t < jornadas.length; t++){
		p = document.getElementById('contentInfo');
		newElement = document.createElement('div');	
		newElement.innerHTML = "<table id = "+jornadas[t]+"><tr><td>Jornada</td><td>Visitante</td><td>Fecha</td><td>Casa</td></tr></table>";
		p.appendChild(newElement);
		for( i = 0; i< encuentros.length; i++){
			if(encuentros[i].matchday === jornadas[t]){
				visitante = encuentros[i].awayTeam.name;
				casa = encuentros[i].homeTeam.name;
				fecha = encuentros[i].utcDate;
				jornada = encuentros[i].matchday;
		    	p = document.getElementById(jornadas[t]);
			    newElement = document.createElement('tr');
			    newElement.setAttribute('id', 'info' + i);
			    newElement.innerHTML = "<td>"+jornada+"</td>"+"<td>"+visitante+"</td>"+"<td>"+fecha+"</td>"+"<td>"+casa+"</td>";
			    p.appendChild(newElement);
			}
		}
	}
}

function requestInformacionEquipo(jsonData,equipo){				
	//console.log(jsonData);
	equipos = jsonData.teams;
	equipoInfo = 0;
	for(i = 0; i < equipos.length; i++){
		if(equipos[i].name === equipo){
			equipoInfo = equipos[i];
			i = equipos.length;
		}
	}
	//console.log(equipoInfo);
	nombre = equipoInfo.name;
	escudo = equipoInfo.crestUrl;
	fundacion = equipoInfo.founded;
	ubicacion = equipoInfo.address;		
	id = equipoInfo.id;	
	var p = document.getElementById('content');
	var newElement = document.createElement('div');
	newElement.setAttribute('id', 'contentInfo');
	escudo = equipoInfo.crestUrl;
	if (escudo === "" || escudo ===null){
		escudo = "images/default.png"
	}		
	newElement.innerHTML = 
	"<div><img class = 'escudoBig' src = "+ escudo+"></div>" +
	"<table><tr><td>Nombre: </td><td>"+nombre+"</td></tr>"+	
	"<tr><td>Año de fundación: </td><td>"+fundacion+"</td></tr>"+
	"<tr><td>Ubicación: </td><td>"+ubicacion+"</td></tr></table>";
	p.appendChild(newElement);
	mostrarInformacionJugadores(id);
}

function requestInformacionJugadores(jsonData){	
	jugadores = jsonData.squad;	
	var p = document.getElementById('contentInfo');	
	for(i = 0; i < jugadores.length; i++){
		jugador = jugadores[i].name;
		nacimiento = jugadores[i].dateOfBirth;
		posicion = jugadores[i].role;
		nacionalidad = jugadores[i].nationality;
		numero = jugadores[i].shirtNumber;
		if(numero === "" || numero === null){
			numero = "Ninguno"
		}
		newElement = document.createElement('table');
		newElement.innerHTML =
		"<div>"+
		"<tr><td>Número de jugador: </td><td>"+numero+"</td></tr>"+
		"<tr><td>Nombre: </td><td>"+jugador+"</td></tr>"+ 
		"<tr><td>Fecha de nacimiento: </td><td>"+nacimiento+"</td></tr>"+
		"<tr><td>Nacionalidad: </td><td>"+nacionalidad+"</td></tr>"+
		"<tr><td>Posición: </td><td>"+posicion+"</td></tr>"+
		"</div>";
		p.appendChild(newElement);
	}	
}

function obtenerTablas(data){
	tablas = [data[0].stage];	
	for (i = 0; i < data.length; i++){
		if(data[i].stage !== tablas[tablas.length - 1]){
			tablas.push(data[i].stage);
		}
	}
	return tablas;
}

function obtenerJornadas(data){
	jornadas = [data[0].matchday];	
	for (i = 0; i < data.length; i++){
		if(data[i].matchday !== jornadas[jornadas.length - 1]){
			jornadas.push(data[i].matchday);
		}
	}
	return jornadas;
}

function mostrarInformacionJugadores(idEquipo){
	url = 'https://api.football-data.org/v2/teams/'+idEquipo
    requestInformacion(6, url,0);
}

function mostrarTablas(){
	removeElement('contentInfo');
	id = processUser();
	url = 'https://api.football-data.org/v2/competitions/'+id+'/standings' ;
	requestInformacion(1, url,0);
}

function mostrarResultados(){
	removeElement('contentInfo');
	id = processUser();	
	url = 'https://api.football-data.org/v2/competitions/'+id+'/matches?status=FINISHED';
	requestInformacion(2, url,0);
}

function mostrarHorarios(){
	removeElement('contentInfo');
	id = processUser();	
	url = 'https://api.football-data.org/v2/competitions/'+id+'/matches?status=SCHEDULED';
	requestInformacion(3, url,0);
}

function mostrarResultadosTemporada(anio){
	removeElement('contentInfo');	
	id = processUser();	
	url = 'https://api.football-data.org/v2/competitions/'+id+'/matches?season='+anio;
	requestInformacion(4, url, 0);
}

function mostrarInformacionEquipo(nombre){
	removeElement('contentInfo');
	id = processUser();		
	url = 'https://api.football-data.org/v2/competitions/'+id+'/teams';
	requestInformacion(5, url, nombre);
}

function test(data){
	console.log(data);
}

function addElement(parentId, elementTag, elementId, html) {
    // Adds an element to the document
    var p = document.getElementById(parentId);
    var newElement = document.createElement(elementTag);
    newElement.setAttribute('id', elementId);
    newElement.innerHTML = html;
    p.appendChild(newElement);
}

function removeElement(elementId) {
    // Removes an element from the document
    var element = document.getElementById(elementId);
    element.parentNode.removeChild(element);
}

function processUser()
  {
    var parameters = location.search.substring(1).split("&");

    var temp = parameters[0].split("=");
    l = unescape(temp[1]);
    return l;
  }
